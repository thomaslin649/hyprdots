# Colors

- <div style="color:#367B42">Green</div>
- <div style="color:#A44185">Magenta</div>
- <div style="color:#012339">"Black"</div>
- <div style="color:#2770C0">Blue</div>
- <div style="color:#1E4C84">Darker Blue</div>
- brown: #A56416
- string: "#3d9189"
- Error, red: #EC0303

Typescript: #2b7ad5"
