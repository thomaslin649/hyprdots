# Material Theme Kit

A set of themes based on [equinusocio/material-theme](https://github.com/equinusocio/material-theme).

## Material

![](https://raw.githubusercontent.com/Microsoft/vscode-themes/master/material/images/material-preview.png)

## Material Night

![](https://raw.githubusercontent.com/Microsoft/vscode-themes/master/material/images/material-night-preview.png)

## Material Night Eighties

![](https://raw.githubusercontent.com/Microsoft/vscode-themes/master/material/images/material-night-eighties-preview.png)

# LICENSE
[MIT](https://github.com/Microsoft/vscode-themes/blob/master/LICENSE.txt)